from project.clients.base_client import BaseClient
import math

class VIPClient(BaseClient):
    MEMBERSHIP_TYPE = "VIP"
    def __init__(self,name: str):
        super().__init__(name,self.MEMBERSHIP_TYPE)

    def earning_points(self,order_amount: float):
        self.point = math.floor(5/order_amount)
        self.points += self.point
        return self.point



