from  project.teacher import Teacher
t = Teacher()
print(t.teach())
print(t.sleep())
print(t.get_fired())